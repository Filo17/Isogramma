﻿//Ambrogiani Filippo 3i 18/02/2023
using System;
using System.Linq;

public static class Isogramma
{
    public static bool Verifica(string word)
    {
        //rimpiazzo i caratteri speciali per evitare errori
        word = word.Replace(" ", "");
        word = word.Replace("-", "");
        word = word.ToLower();
        int lunghezzaParola;
        bool LettereUguali = true;
        lunghezzaParola = word.Length;
        //controllo che la parola non sia vuota
        if (lunghezzaParola <= 0){
            return true;
        }
            
        for (int j = 0; j < lunghezzaParola; j++)
        {
            for (int i = 0; i < lunghezzaParola; i++)
            {
                //faccio questo controllo per evitare che i due contatori dei cicli collidano
                if (i == j)
                {
                    LettereUguali = true;
                }
                
                if (word[j] == word[i] && LettereUguali == false)
                {
                    return false;
                }
                LettereUguali = false;

            }
        }
        return true;
    }

}
